module.exports = {
  setupFilesAfterEnv: ["<rootDir>/tests/setup.js"],
  testEnvironment: "node",
  testMatch: ["**/backend/tests/**/*.test.js"],
};
