export const useNavigate = () => jest.fn();
