module.exports = {
    testEnvironment: "jsdom",
  };
  